package com.example.pr2.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

import java.util.List;
@Entity
@Table(name = "libraries")
public class LibraryModel {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "Поле 'Name' не может быть пустым")
    @Size(max = 255, message = "Поле 'Name' не может содержать более 255 символов")
    private String name;

    @NotBlank(message = "Поле 'Address' не может быть пустым")
    @Size(max = 255, message = "Поле 'Address' не может содержать более 255 символов")
    private String address;

    @NotBlank(message = "Поле 'City' не может быть пустым")
    @Size(max = 255, message = "Поле 'City' не может содержать более 255 символов")
    private String city;

    @NotBlank(message = "Поле 'State' не может быть пустым")
    @Size(max = 255, message = "Поле 'State' не может содержать более 255 символов")
    private String state;

    @NotBlank(message = "Поле 'Postal Code' не может быть пустым")
    @Size(max = 20, message = "Поле 'Postal Code' не может содержать более 20 символов")
    private String postalCode;

    // Существующая связь OneToMany с BookModel
    @OneToMany(mappedBy = "library", cascade = CascadeType.ALL)
    private List<BookModel> books;

    @OneToOne
    @JoinColumn(name = "user_id") // Указываем имя столбца, который ссылается на UserModel
    private UserModel user;
    public List<BookModel> getBooks() {
        return books;
    }

    public void setBooks(List<BookModel> books) {
        this.books = books;
    }

    // Геттер и сеттер для user
    public UserModel getUser() {
        return user;
    }
    public void setUser(UserModel user) {
        this.user = user;
    }
    public Long getId() {
        return id;
    }
    public void setId(Long id) {
        this.id = id;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getAddress() {
        return address;
    }
    public void setAddress(String address) {
        this.address = address;
    }
    public String getCity() {
        return city;
    }
    public void setCity(String city) {
        this.city = city;
    }
    public String getState() {
        return state;
    }
    public void setState(String state) {
        this.state = state;
    }
    public String getPostalCode() {
        return postalCode;
    }
    public void setPostalCode(String postalCode) {
        this.postalCode = postalCode;
    }
}