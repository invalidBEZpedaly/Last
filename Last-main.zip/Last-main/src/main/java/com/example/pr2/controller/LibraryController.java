package com.example.pr2.controller;

import com.example.pr2.model.LibraryModel;
import com.example.pr2.model.UserModel;
import com.example.pr2.repo.libraryRepository;
import com.example.pr2.repo.userRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
@Controller
@RequestMapping("/libraries")
public class LibraryController {

    @Autowired
    private libraryRepository _libraryRepository;

    @Autowired
    private userRepository _userRepository;

    @GetMapping()
    public String listLibraries(Model model) {
        Iterable<LibraryModel> libraries = _libraryRepository.findAll();
        model.addAttribute("libraries", libraries);
        return "library/list";
    }

    @GetMapping("/new")
    public String newLibraryForm(Model model) {
        LibraryModel library = new LibraryModel();
        model.addAttribute("library", library);
        return "library/new";
    }

    @PostMapping("/new")
    public String createLibrary(@ModelAttribute("library") LibraryModel library) {
        _libraryRepository.save(library);
        return "redirect:/libraries";
    }

    @GetMapping("/{id}/edit")
    public String editLibraryForm(@PathVariable Long id, Model model) {
        LibraryModel library = _libraryRepository.findById(id).orElse(null);
        if (library == null) {
            return "redirect:/libraries";
        }
        model.addAttribute("library", library);
        return "library/edit";
    }

    @PostMapping("/{id}/edit")
    public String updateLibrary(@PathVariable Long id, @ModelAttribute("library") LibraryModel library) {
        library.setId(id);
        _libraryRepository.save(library);
        return "redirect:/libraries";
    }

    @GetMapping("/{id}/delete")
    public String deleteLibrary(@PathVariable Long id) {
        _libraryRepository.deleteById(id);
        return "redirect:/libraries";
    }

    @GetMapping("/{id}/user")
    public String viewUserForLibrary(@PathVariable Long id, Model model) {
        LibraryModel library = _libraryRepository.findById(id).orElse(null);
        if (library == null) {
            return "redirect:/libraries";
        }
        UserModel user = library.getUser();
        model.addAttribute("user", user);
        return "library/viewUser";
    }
}

