package com.example.pr2.repo;

import com.example.pr2.model.LibraryStaff;
import org.springframework.data.jpa.repository.JpaRepository;

public interface LibraryStaffRepository extends JpaRepository<LibraryStaff, Long> {
}
