package com.example.pr2.repo;

import com.example.pr2.model.AuthorModel;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface authorRepository extends JpaRepository<AuthorModel, Long> {
}
