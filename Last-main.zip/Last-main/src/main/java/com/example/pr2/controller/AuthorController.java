package com.example.pr2.controller;
import com.example.pr2.model.AuthorModel;
import com.example.pr2.model.BookModel;
import com.example.pr2.repo.authorRepository;
import com.example.pr2.repo.bookRepository;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/authors")
public class AuthorController {

    private final authorRepository _authorRepository;
    private final bookRepository _bookRepository;

    public AuthorController(authorRepository _authorRepository, bookRepository _bookRepository) {
        this._authorRepository = _authorRepository;
        this._bookRepository = _bookRepository;
    }

    @GetMapping()
    public String listAuthors(Model model) {
        List<AuthorModel> authors = _authorRepository.findAll();
        model.addAttribute("authors", authors);
        return "author/indexAuthor";
    }

    @GetMapping("/new")
    public String newAuthorForm(Model model) {
        AuthorModel author = new AuthorModel();
        model.addAttribute("author", author);
        return "author/newAuthor";
    }

    @PostMapping("/new")
    public String createAuthor(@ModelAttribute("author") AuthorModel author) {
        try {
            _authorRepository.save(author);
            System.out.println("Author created: " + author.getFullName()); // Вывод информации о создании автора
        } catch (Exception e) {
            System.err.println("Error creating author: " + e.getMessage()); // Вывод информации об ошибке
        }
        return "redirect:/authors";
    }

    @GetMapping("/{id}/edit")
    public String editAuthorForm(@PathVariable Long id, Model model) {
        AuthorModel author = _authorRepository.findById(id).orElse(null);
        if (author == null) {
            return "redirect:/authors";
        }
        model.addAttribute("author", author);
        return "author/editAuthor";
    }

    @PostMapping("/{id}/edit")
    public String updateAuthor(@PathVariable Long id, @ModelAttribute("author") AuthorModel author) {
        author.setId(id);
        _authorRepository.save(author);
        return "redirect:/authors";
    }

    @GetMapping("/{id}/delete")
    public String deleteAuthor(@PathVariable Long id) {
        _authorRepository.deleteById(id);
        return "redirect:/authors";
    }

    @GetMapping("/{id}/books")
    public String listBooksByAuthor(@PathVariable Long id, Model model) {
        AuthorModel author = _authorRepository.findById(id).orElse(null);
        if (author == null) {
            return "redirect:/authors";
        }
        List<BookModel> books = _bookRepository.findByAuthor(author);
        model.addAttribute("author", author);
        model.addAttribute("books", books);
        return "book/bookList";
    }
}

