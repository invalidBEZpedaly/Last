package com.example.pr2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Pr2Application {

    public static void main(String[] args) {
        SpringApplication.run(Pr2Application.class, args);
    }

}
