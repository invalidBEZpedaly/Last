package com.example.pr2.controller;

import com.example.pr2.model.AuthorModel;
import com.example.pr2.model.BookModel;
import com.example.pr2.model.LibraryModel;
import com.example.pr2.repo.authorRepository;
import com.example.pr2.repo.bookRepository;
import com.example.pr2.repo.libraryRepository;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/books")
public class BookController {

    public final libraryRepository _libraryRepository;
    public final bookRepository _bookRepository;
    public final authorRepository _authorRepository;

    public BookController(libraryRepository _libraryRepository, bookRepository _bookRepository, authorRepository authorRepository) {
        this._libraryRepository = _libraryRepository;
        this._bookRepository = _bookRepository;
        _authorRepository = authorRepository;
    }

    @GetMapping()
    public String listBooks(Model model) {
        List<BookModel> books = _bookRepository.findAll();
        model.addAttribute("books", books);
        return "book/bookList";
    }

    @GetMapping("/new")
    public String newBookForm(Model model) {
        List<LibraryModel> libraries = _libraryRepository.findAll();
        model.addAttribute("libraries", libraries);

        // Получите список всех авторов и добавьте его в модель
        List<AuthorModel> authors = _authorRepository.findAll();

        // Проверьте, что список авторов не является null и не пустым
        if (authors != null && !authors.isEmpty()) {
            model.addAttribute("authors", authors);
        }

        BookModel book = new BookModel();
        model.addAttribute("book", book);

        // Добавьте автора в модель
        AuthorModel author = new AuthorModel();
        model.addAttribute("author", author);

        return "book/new";
    }

    @PostMapping("/new")
    public String createBook(@ModelAttribute("book") BookModel book,
                             @RequestParam("authorId") Long authorId) {
        AuthorModel author = _authorRepository.findById(authorId).orElse(null);
        if (author != null) {
            book.setAuthor(author);
        }

        try {
            _bookRepository.save(book);
            System.out.println("Book created: " + book.getTitle()); // Вывод информации о создании книги
        } catch (Exception e) {
            System.err.println("Error creating book: " + e.getMessage()); // Вывод информации об ошибке
        }

        return "redirect:/books";
    }

    @GetMapping("/{id}/edit")
    public String editBookForm(@PathVariable Long id, Model model) {
        BookModel book = _bookRepository.findById(id).orElse(null);
        if (book == null) {
            return "redirect:/books";
        }
        model.addAttribute("book", book);
        return "book/edit";
    }

    @PostMapping("/{id}/edit")
    public String updateBook(@PathVariable Long id, @ModelAttribute("book") BookModel book) {
        book.setId(id);
        _bookRepository.save(book);
        return "redirect:/books";
    }

    @GetMapping("/{id}/delete")
    public String deleteBook(@PathVariable Long id) {
        _bookRepository.deleteById(id);
        return "redirect:/books";
    }

    @GetMapping("/libraries/{libraryId}/books")
    public String listBooksForLibrary(@PathVariable Long libraryId, Model model) {
        LibraryModel library = _libraryRepository.findById(libraryId).orElse(null);
        if (library == null) {
            return "redirect:/libraries";
        }
        List<BookModel> books = (List<BookModel>) _bookRepository.findByLibrary(library);
        model.addAttribute("library", library);
        model.addAttribute("books", books);
        return "book/bookList";
    }
}
