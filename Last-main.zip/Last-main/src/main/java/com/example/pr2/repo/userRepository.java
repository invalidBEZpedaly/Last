package com.example.pr2.repo;

import com.example.pr2.model.LibraryModel;
import com.example.pr2.model.UserModel;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface userRepository extends JpaRepository<UserModel, Long> {
    UserModel findByLibrary(LibraryModel library);
    List<UserModel> findAll();
}
