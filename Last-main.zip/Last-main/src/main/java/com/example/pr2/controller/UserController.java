package com.example.pr2.controller;

import com.example.pr2.model.LibraryModel;
import com.example.pr2.model.UserModel;
import com.example.pr2.repo.libraryRepository;
import com.example.pr2.repo.userRepository;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/users")
public class UserController {

    private final userRepository _userRepository;

    private final libraryRepository _libraryRepository;

    public UserController(userRepository userRepository, libraryRepository libraryRepository) {
        this._userRepository = userRepository;
        this._libraryRepository = libraryRepository;
    }


    @GetMapping()
    public String listUsers(Model model) {
        Iterable<UserModel> users = _userRepository.findAll();
        model.addAttribute("users", users);
        return "user/indexUser";
    }

    @GetMapping("/new")
    public String newUser(Model model) {
        UserModel user = new UserModel();
        Iterable<LibraryModel> libraries = _libraryRepository.findAll();
        model.addAttribute("user", user);
        model.addAttribute("libraries", libraries);
        return "user/newUser";
    }

    @PostMapping("/new")
    public String createUser(@ModelAttribute("user") UserModel user, @RequestParam("libraryId") Long libraryId) {
        // Получить библиотеку по ID
        LibraryModel library = _libraryRepository.findById(libraryId).orElse(null);

        // Привязать выбранную библиотеку к пользователю
        if (library != null) {
            user.setLibrary(library);
        }
        // Сохранить пользователя
        _userRepository.save(user);

        return "redirect:/users";
    }

    @PostMapping("/newWithLibrary")
    public String createUserWithLibrary(@ModelAttribute("user") UserModel user, @RequestParam("libraryId") Long libraryId) {
        LibraryModel library = _libraryRepository.findById(libraryId).orElse(null);

        if (library != null) {
            user.setLibrary(library);
            _userRepository.save(user);
        }

        return "redirect:/users";
    }



    @GetMapping("/{id}/edit")
    public String editUserForm(@PathVariable Long id, Model model) {
        UserModel user = _userRepository.findById(id).orElse(null);
        if (user == null) {
            return "redirect:/users";
        }
        model.addAttribute("user", user);
        return "user/editUser";
    }

    @PostMapping("/{id}/edit")
    public String updateUser(@PathVariable Long id, @ModelAttribute("user") UserModel user) {
        user.setId(id);
        _userRepository.save(user);
        return "redirect:/users";
    }

    @GetMapping("/{id}/delete")
    public String deleteUser(@PathVariable Long id) {
        _userRepository.deleteById(id);
        return "redirect:/users";
    }


}
