package com.example.pr2.controller;

import com.example.pr2.model.LibraryStaff;
import com.example.pr2.repo.LibraryStaffRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/staffs")
public class LibraryStaffController {

    private final LibraryStaffRepository staffRepository;

    @Autowired
    public LibraryStaffController(LibraryStaffRepository LibraryStaffRepository) {
        staffRepository = LibraryStaffRepository;
    }

    @GetMapping()
    public String listLibraries(Model model) {
        Iterable<LibraryStaff> staffs = staffRepository.findAll();
        model.addAttribute("staffs", staffs);
        return "staff/list";
    }

    @GetMapping("/new")
    public String newLibraryForm(Model model) {
        LibraryStaff staff = new LibraryStaff();
        model.addAttribute("staff", staff);
        return "staff/new";
    }

    @PostMapping("/new")
    public String createLibrary(@ModelAttribute("staff") LibraryStaff staff) {
        staffRepository.save(staff);
        return "redirect:/staffs";
    }

    @GetMapping("/{id}/edit")
    public String editLibraryForm(@PathVariable Long id, Model model) {
        LibraryStaff staff = staffRepository.findById(id).orElse(null);
        if (staff == null) {
            return "redirect:/staffs";
        }
        model.addAttribute("staff", staff);
        return "staff/edit";
    }

    @PostMapping("/{id}/edit")
    public String updateLibrary(@PathVariable Long id, @ModelAttribute("staff") LibraryStaff staff) {
        staff.setId(id);
        staffRepository.save(staff);
        return "redirect:/staffs";
    }

    @GetMapping("/{id}/delete")
    public String deleteLibrary(@PathVariable Long id) {
        staffRepository.deleteById(id);
        return "redirect:/staffs";
    }
}