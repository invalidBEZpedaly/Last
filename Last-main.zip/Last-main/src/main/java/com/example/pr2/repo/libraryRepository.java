package com.example.pr2.repo;


import com.example.pr2.model.LibraryModel;
import org.springframework.data.jpa.repository.JpaRepository;

public interface libraryRepository extends JpaRepository<LibraryModel, Long> {

}
