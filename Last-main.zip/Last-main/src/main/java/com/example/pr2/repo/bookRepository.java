package com.example.pr2.repo;

import com.example.pr2.model.AuthorModel;
import com.example.pr2.model.BookModel;
import com.example.pr2.model.LibraryModel;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface bookRepository extends JpaRepository<BookModel, Long> {
    BookModel findByLibrary(LibraryModel library);
    List<BookModel> findAll();

    List<BookModel> findByAuthor(AuthorModel author);
}
